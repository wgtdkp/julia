# julia
##a simple http server in c
### ENVIRONMENT
>* ubuntu 14.04
* gcc 4.8.4
* kernel 3.13.0

### MAKE
```shell
$ make julia
```
### DEPENDENCIES
1. to support php script, you need php5-cgi
```
     $ sudo apt-get install php5-cgi
```
### RUN
```
$ sudo ./julia 80 ./www
```
